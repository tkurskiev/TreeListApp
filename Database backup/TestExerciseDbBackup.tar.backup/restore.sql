--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.0
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "TestExercise";
--
-- Name: TestExercise; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "TestExercise" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE "TestExercise" OWNER TO postgres;

\connect "TestExercise"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "TestExercise"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "TestExercise" IS 'Database for test exercize from ETS company.';


--
-- Name: app; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO postgres;

--
-- Name: SCHEMA app; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA app IS 'App schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: catalog; Type: TABLE; Schema: app; Owner: postgres
--

CREATE TABLE app.catalog (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text
);


ALTER TABLE app.catalog OWNER TO postgres;

--
-- Name: COLUMN catalog.id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog.id IS 'Unique id for the catalog table row, containing company information';


--
-- Name: COLUMN catalog.name; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog.name IS 'Manufacturing company name';


--
-- Name: COLUMN catalog.description; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog.description IS 'Description of the company';


--
-- Name: catalog_aggregate; Type: TABLE; Schema: app; Owner: postgres
--

CREATE TABLE app.catalog_aggregate (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    url character varying(2500),
    catalog_id integer
);


ALTER TABLE app.catalog_aggregate OWNER TO postgres;

--
-- Name: COLUMN catalog_aggregate.id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_aggregate.id IS 'Unique id for the catalog_aggregate table row, containing aggregate (or in other words, part type) information';


--
-- Name: COLUMN catalog_aggregate.name; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_aggregate.name IS 'Particular aggregate''s name';


--
-- Name: COLUMN catalog_aggregate.description; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_aggregate.description IS 'Description of the aggregate';


--
-- Name: COLUMN catalog_aggregate.url; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_aggregate.url IS 'Url link for page, containing info about the aggregate';


--
-- Name: COLUMN catalog_aggregate.catalog_id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_aggregate.catalog_id IS 'Foreign key to table app.catalog; company id, which produces this aggregate';


--
-- Name: catalog_aggregate_id_seq; Type: SEQUENCE; Schema: app; Owner: postgres
--

CREATE SEQUENCE app.catalog_aggregate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app.catalog_aggregate_id_seq OWNER TO postgres;

--
-- Name: catalog_aggregate_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: postgres
--

ALTER SEQUENCE app.catalog_aggregate_id_seq OWNED BY app.catalog_aggregate.id;


--
-- Name: catalog_id_seq; Type: SEQUENCE; Schema: app; Owner: postgres
--

CREATE SEQUENCE app.catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app.catalog_id_seq OWNER TO postgres;

--
-- Name: catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: postgres
--

ALTER SEQUENCE app.catalog_id_seq OWNED BY app.catalog.id;


--
-- Name: catalog_level; Type: TABLE; Schema: app; Owner: postgres
--

CREATE TABLE app.catalog_level (
    id integer NOT NULL,
    parent_id integer,
    name character varying(200) NOT NULL,
    description text
);


ALTER TABLE app.catalog_level OWNER TO postgres;

--
-- Name: COLUMN catalog_level.id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_level.id IS 'Unique id for the catalog_level table row';


--
-- Name: COLUMN catalog_level.parent_id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_level.parent_id IS 'Catalog item''s parent id, if null - row contains info about company';


--
-- Name: COLUMN catalog_level.name; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_level.name IS 'Catalog item''s name';


--
-- Name: COLUMN catalog_level.description; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_level.description IS 'Catalog item''s description';


--
-- Name: catalog_level_id_seq; Type: SEQUENCE; Schema: app; Owner: postgres
--

CREATE SEQUENCE app.catalog_level_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app.catalog_level_id_seq OWNER TO postgres;

--
-- Name: catalog_level_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: postgres
--

ALTER SEQUENCE app.catalog_level_id_seq OWNED BY app.catalog_level.id;


--
-- Name: catalog_model; Type: TABLE; Schema: app; Owner: postgres
--

CREATE TABLE app.catalog_model (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    url character varying(2500),
    catalog_aggregate_id integer
);


ALTER TABLE app.catalog_model OWNER TO postgres;

--
-- Name: COLUMN catalog_model.id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_model.id IS 'Unique id for the catalog_model table row, containing aggregate model (or in other words, part model) information';


--
-- Name: COLUMN catalog_model.name; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_model.name IS 'Concrete aggregate model''s name';


--
-- Name: COLUMN catalog_model.description; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_model.description IS 'Model''s description';


--
-- Name: COLUMN catalog_model.url; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_model.url IS 'Url link for page, containing info about the model, or where it can be bought';


--
-- Name: COLUMN catalog_model.catalog_aggregate_id; Type: COMMENT; Schema: app; Owner: postgres
--

COMMENT ON COLUMN app.catalog_model.catalog_aggregate_id IS 'Foreign key to table app.catalog_aggregate; aggregate id, of which type this model is';


--
-- Name: catalog_model_id_seq; Type: SEQUENCE; Schema: app; Owner: postgres
--

CREATE SEQUENCE app.catalog_model_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE app.catalog_model_id_seq OWNER TO postgres;

--
-- Name: catalog_model_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: postgres
--

ALTER SEQUENCE app.catalog_model_id_seq OWNED BY app.catalog_model.id;


--
-- Name: catalog id; Type: DEFAULT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog ALTER COLUMN id SET DEFAULT nextval('app.catalog_id_seq'::regclass);


--
-- Name: catalog_aggregate id; Type: DEFAULT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_aggregate ALTER COLUMN id SET DEFAULT nextval('app.catalog_aggregate_id_seq'::regclass);


--
-- Name: catalog_level id; Type: DEFAULT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_level ALTER COLUMN id SET DEFAULT nextval('app.catalog_level_id_seq'::regclass);


--
-- Name: catalog_model id; Type: DEFAULT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_model ALTER COLUMN id SET DEFAULT nextval('app.catalog_model_id_seq'::regclass);


--
-- Data for Name: catalog; Type: TABLE DATA; Schema: app; Owner: postgres
--

COPY app.catalog (id, name, description) FROM stdin;
\.
COPY app.catalog (id, name, description) FROM '$$PATH$$/2850.dat';

--
-- Data for Name: catalog_aggregate; Type: TABLE DATA; Schema: app; Owner: postgres
--

COPY app.catalog_aggregate (id, name, description, url, catalog_id) FROM stdin;
\.
COPY app.catalog_aggregate (id, name, description, url, catalog_id) FROM '$$PATH$$/2852.dat';

--
-- Data for Name: catalog_level; Type: TABLE DATA; Schema: app; Owner: postgres
--

COPY app.catalog_level (id, parent_id, name, description) FROM stdin;
\.
COPY app.catalog_level (id, parent_id, name, description) FROM '$$PATH$$/2856.dat';

--
-- Data for Name: catalog_model; Type: TABLE DATA; Schema: app; Owner: postgres
--

COPY app.catalog_model (id, name, description, url, catalog_aggregate_id) FROM stdin;
\.
COPY app.catalog_model (id, name, description, url, catalog_aggregate_id) FROM '$$PATH$$/2854.dat';

--
-- Name: catalog_aggregate_id_seq; Type: SEQUENCE SET; Schema: app; Owner: postgres
--

SELECT pg_catalog.setval('app.catalog_aggregate_id_seq', 3, true);


--
-- Name: catalog_id_seq; Type: SEQUENCE SET; Schema: app; Owner: postgres
--

SELECT pg_catalog.setval('app.catalog_id_seq', 2, true);


--
-- Name: catalog_level_id_seq; Type: SEQUENCE SET; Schema: app; Owner: postgres
--

SELECT pg_catalog.setval('app.catalog_level_id_seq', 9, true);


--
-- Name: catalog_model_id_seq; Type: SEQUENCE SET; Schema: app; Owner: postgres
--

SELECT pg_catalog.setval('app.catalog_model_id_seq', 4, true);


--
-- Name: catalog_aggregate catalog_aggregate_pkey; Type: CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_aggregate
    ADD CONSTRAINT catalog_aggregate_pkey PRIMARY KEY (id);


--
-- Name: catalog_level catalog_level_pkey; Type: CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_level
    ADD CONSTRAINT catalog_level_pkey PRIMARY KEY (id);


--
-- Name: catalog_model catalog_model_pkey; Type: CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_model
    ADD CONSTRAINT catalog_model_pkey PRIMARY KEY (id);


--
-- Name: catalog catalog_pkey; Type: CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog
    ADD CONSTRAINT catalog_pkey PRIMARY KEY (id);


--
-- Name: catalog_aggregate catalog_aggregate_catalog_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_aggregate
    ADD CONSTRAINT catalog_aggregate_catalog_id_fkey FOREIGN KEY (catalog_id) REFERENCES app.catalog(id);


--
-- Name: catalog_model catalog_model_catalog_aggregate_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: postgres
--

ALTER TABLE ONLY app.catalog_model
    ADD CONSTRAINT catalog_model_catalog_aggregate_id_fkey FOREIGN KEY (catalog_aggregate_id) REFERENCES app.catalog_aggregate(id);


--
-- PostgreSQL database dump complete
--

